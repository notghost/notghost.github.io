irssi-themes
---
A repository of the themes listed on [irssi's website](http://www.irssi.org/themes).

Check our wikified [Theme Gallery](https://github.com/phracker/irssi-themes/wiki/Theme-Gallery) to preview these.

###Istallation

1. Clone this repository `git clone https://github.com/phracker/irssi-themes`
2. Copy the theme you want to use to `~/.irssi`
3. From irssi: `/set theme theme_name`